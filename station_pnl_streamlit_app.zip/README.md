# Franchise Station P&L Streamlit App

Bu uygulama SAP'den alınan CSV/Excel P&L verisini yükleyerek istasyon bazında P&L dashboard oluşturur.

## Çalıştırma

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Beklenen veri formatı

Ana kolonlar:

- Year_Month_Quarter
- Year
- Quarter
- Contract_Beginning
- Contract_Expiration
- İstasyon
- Name
- District
- City
- Territory
- Territory_Manager
- Area_Sales_Manager
- Dealer/Acenta
- Supply_city_for_fuel
- Attribute.1
- Attribute.2
- Currency_Type
- Value

## Öneri

Büyük dosyalarda Excel yerine CSV yüklemek daha hızlıdır.
